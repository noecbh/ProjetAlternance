#include "../include/plannings.h"
#include <stdio.h>
#include <stdlib.h>

void generer_planning(Lutin *lutins, int nb_lutins, LigneFabrication *lignes, int nb_lignes, int jour) {
    int i, j, lutin_index;
    int nb_bricoleurs = 0, nb_controleurs = 0, nb_empaqueteurs = 0;
    Lutin *bricoleurs[nb_lutins], *controleurs[nb_lutins], *empaqueteurs[nb_lutins];

    jour=1;

    /* Initialisation des lignes */
    for (i = 0; i < nb_lignes; i++) {
        lignes[i].bricoleur = NULL;
        lignes[i].controleur = NULL;
        lignes[i].empaqueteur = NULL;
    }

    /* Trier les lutins par rôle */
    for (i = 0; i < nb_lutins; i++) {
        if (lutins[i].statut == 1) {
            if (lutins[i].role == 1) {
                bricoleurs[nb_bricoleurs++] = &lutins[i];
            } else if (lutins[i].role == 2) {
                controleurs[nb_controleurs++] = &lutins[i];
            } else if (lutins[i].role == 3) {
                empaqueteurs[nb_empaqueteurs++] = &lutins[i];
            }
        }
    }

    /* Vérifier si assez de lutins sont disponibles */
    if (nb_bricoleurs < nb_lignes || nb_controleurs < nb_lignes || nb_empaqueteurs < nb_lignes) {
        printf("Pas assez de lutins disponibles pour remplir toutes les lignes !\n");
        return;
    }

    /* Assigner les lutins en évitant les répétitions */
    for (i = 0; i < nb_lignes; i++) {
        lutin_index = i % nb_bricoleurs;
        lignes[i].bricoleur = bricoleurs[lutin_index];

        lutin_index = i % nb_controleurs;
        lignes[i].controleur = controleurs[lutin_index];

        lutin_index = i % nb_empaqueteurs;
        lignes[i].empaqueteur = empaqueteurs[lutin_index];
    }
}



void afficher_planning(LigneFabrication *lignes, int nb_lignes, int jour) {
    int heure,role,lutin_trouve,ligne_num,k,debut,fin;
    const char *jours[] = {"Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"};

    printf("\nPLANNING DU %s\n", jours[jour]);

    for (ligne_num = 0; ligne_num < nb_lignes; ligne_num++) {
        printf("\nPLANNING DE LA LIGNE %d\n", ligne_num + 1);
        printf("+------------------------------------------------------+\n");
        printf("| Heure | Bricoleur       | Contrôleur       | Empaqueteur       |\n");
        printf("+------------------------------------------------------+\n");

        for (heure = 0; heure < 24; heure++) {
            printf("|  %dh  ", heure);

            for (role = 1; role <= 3; role++) {
                lutin_trouve = 0;
                Lutin *lutin = NULL;

                if (role == 1) lutin = lignes[ligne_num].bricoleur;
                if (role == 2) lutin = lignes[ligne_num].controleur;
                if (role == 3) lutin = lignes[ligne_num].empaqueteur;

                if (lutin != NULL) {
                    for (k = 0; k < lutin->nb_plages[jour]; k++) {
                        debut = lutin->horaires[jour][k].debut;
                        fin = lutin->horaires[jour][k].fin;

                        /*Cas normal (début < fin)*/ 
                        if (heure >= debut && heure < fin) {
                            printf("| %s ", lutin->prenom);
                            lutin_trouve = 1;
                        }

                        /* Cas où le créneau traverse minuit (ex: 22h - 6h)*/
                        if (debut > fin) {
                            if (heure >= debut || heure < fin) {
                                printf("| %s ", lutin->prenom);
                                lutin_trouve = 1;
                            }
                        }
                    }
                }

                if (!lutin_trouve) {
                    printf("| Personne       ");
                }
            }
            printf("|\n");
        }

        printf("+------------------------------------------------------+\n");
    }
}








void calculer_horaires_ligne(LigneFabrication *ligne) {
    int jour,debut,fin,i,k;
    for (jour = 0; jour < 7; jour++) {
        /* Pour chaque jour de la semaine, on cherche l'heure la plus tôt et la plus tardive parmi les lutins*/
        debut = 0; 
        fin = 23;     

        for (i = 0; i < 3; i++) {
            Lutin *lutin = NULL;
            if (i == 0) lutin = ligne->bricoleur;
            if (i == 1) lutin = ligne->controleur;
            if (i == 2) lutin = ligne->empaqueteur;

            if (lutin != NULL && lutin->statut == 1) { 
                for (k = 0; k < lutin->nb_plages[jour]; k++) {
                    if (lutin->horaires[jour][k].debut < debut) debut = lutin->horaires[jour][k].debut;
                    if (lutin->horaires[jour][k].fin > fin) fin = lutin->horaires[jour][k].fin;
                }
            }
        }

        /* Si au moins un lutin est affecté, on définit l'horaire pour ce jour*/
        if (debut != 24 && fin != 0) {
            ligne->horaires[jour].debut = debut;
            ligne->horaires[jour].fin = fin;
        } else {
            /*Si aucun lutin n'a de créneau pour ce jour, on met des horaires vides*/
            ligne->horaires[jour].debut = 0;
            ligne->horaires[jour].fin = 0;
        }
    }
}

void gerer_planning_manuel(Lutin *lutins, int nb_lutins, LigneFabrication *lignes, int nb_lignes, int jour, int debut, int fin) {
    int lutin_utilise[nb_lutins]; 
    int i, id_bricoleur, id_controleur, id_empaqueteur;
    for (i = 0; i < nb_lutins; i++) lutin_utilise[i] = 0; 

    for (i = 0; i < nb_lignes; i++) {
        printf("\nConfiguration de la ligne %d\n", i + 1);

        /* Choix du bricoleur*/
        if (!afficher_lutins_disponibles(lutins, nb_lutins, 1, lutin_utilise, jour, debut, fin)) {
            printf("\nRREUR : Plus de bricoleur disponible ! Annulation du planning.\n");
            return;
        }
        do {
            printf("\nChoisissez un bricoleur (ID) : ");
            if (scanf("%d", &id_bricoleur)==1){
                printf("OK");
            };
        } while (id_bricoleur < 0 || id_bricoleur >= nb_lutins || lutin_utilise[id_bricoleur] || lutins[id_bricoleur].role != 1);
        lignes[i].bricoleur = &lutins[id_bricoleur];
        lutin_utilise[id_bricoleur] = 1;

        /*Choix du contrôleur*/
        if (!afficher_lutins_disponibles(lutins, nb_lutins, 2, lutin_utilise, jour, debut, fin)) {
            printf("\nERREUR : Plus de contrôleur disponible ! Annulation du planning.\n");
            return;
        }
        do {
            printf("\nChoisissez un contrôleur (ID) : ");
            if (scanf("%d", &id_controleur)==1){
                printf("OK");
            };
        } while (id_controleur < 0 || id_controleur >= nb_lutins || lutin_utilise[id_controleur] || lutins[id_controleur].role != 2);
        lignes[i].controleur = &lutins[id_controleur];
        lutin_utilise[id_controleur] = 1;

        /*Choix de l'empaqueteur*/
        if (!afficher_lutins_disponibles(lutins, nb_lutins, 3, lutin_utilise, jour, debut, fin)) {
            printf("\nERREUR : Plus d'empaqueteur disponible ! Annulation du planning.\n");
            return;
        }
        do {
            printf("\nChoisissez un empaqueteur (ID) : ");
            if (scanf("%d", &id_empaqueteur)==1){
                printf("OK");
            };
        } while (id_empaqueteur < 0 || id_empaqueteur >= nb_lutins || lutin_utilise[id_empaqueteur] || lutins[id_empaqueteur].role != 3);
        lignes[i].empaqueteur = &lutins[id_empaqueteur];
        lutin_utilise[id_empaqueteur] = 1;

        printf("\nLigne %d configurée !\n", i + 1);
    }
}

void creer_planning_optimise(Lutin *lutins, int nb_lutins, LigneFabrication *lignes, int nb_lignes, int jour) {
    int i, j, ligne_courante = 0;
    Lutin *disponibles[3][nb_lutins]; 
    int nb_disponibles[4] = {0}; 

    /* Réinitialisation des lignes */
    for (i = 0; i < nb_lignes; i++) {
        lignes[i].bricoleur = NULL;
        lignes[i].controleur = NULL;
        lignes[i].empaqueteur = NULL;
    }

    /* Trier les lutins par rôle et les stocker */
    for (i = 0; i < nb_lutins; i++) {
        if (lutins[i].statut == 1) {
            int role = lutins[i].role;
            disponibles[role - 1][nb_disponibles[role]++] = &lutins[i];
        }
    }

    /* Vérifier si on peut ouvrir des lignes */
    int max_lignes_ouvertes = nb_disponibles[1];
    if (nb_disponibles[2] < max_lignes_ouvertes) max_lignes_ouvertes = nb_disponibles[2];
    if (nb_disponibles[3] < max_lignes_ouvertes) max_lignes_ouvertes = nb_disponibles[3];

    if (max_lignes_ouvertes == 0) {
        printf("\nImpossible de générer un planning : pas assez de lutins disponibles pour chaque rôle !\n");
        return;
    }

    if (max_lignes_ouvertes > nb_lignes) max_lignes_ouvertes = nb_lignes;

    /* Trier les lutins par rôle en fonction de leur début d'horaire */
    for (i = 0; i < 3; i++) {
        qsort(disponibles[i], nb_disponibles[i + 1], sizeof(Lutin *), comparer_lutins);
    }

    /* Assignation des lutins aux lignes */
    int index[4] = {0}; 

    for (ligne_courante = 0; ligne_courante < max_lignes_ouvertes; ligne_courante++) {
        int prev_fin = 0;  
        
        for (j = 0; j < 3; j++) { 
            int role = j + 1;

            if (index[role] < nb_disponibles[role]) {
                Lutin *lutin = disponibles[role - 1][index[role]++];

                lignes[ligne_courante].horaires[jour].debut = prev_fin;
                lignes[ligne_courante].horaires[jour].fin = prev_fin + 8;
                
                if (role == 1) lignes[ligne_courante].bricoleur = lutin;
                else if (role == 2) lignes[ligne_courante].controleur = lutin;
                else if (role == 3) lignes[ligne_courante].empaqueteur = lutin;

                prev_fin += 8;
            }
        }
    }

    /* Répartition des lutins restants */
    for (j = 1; j <= 3; j++) { 
        while (index[j] < nb_disponibles[j]) {
            Lutin *lutin = disponibles[j - 1][index[j]++];
            int ligne_a_ajouter = -1;

            /* Trouver une ligne où il manque un lutin de ce rôle */
            for (i = 0; i < max_lignes_ouvertes; i++) {
                if ((j == 1 && lignes[i].bricoleur == NULL) ||
                    (j == 2 && lignes[i].controleur == NULL) ||
                    (j == 3 && lignes[i].empaqueteur == NULL)) {
                    ligne_a_ajouter = i;
                    break;
                }
            }

            /* Si aucune ligne incomplète, ajouter sur une ligne existante */
            if (ligne_a_ajouter == -1) {
                ligne_a_ajouter = rand() % max_lignes_ouvertes; 
            }

            /* Ajouter le lutin à la ligne */
            if (j == 1) lignes[ligne_a_ajouter].bricoleur = lutin;
            else if (j == 2) lignes[ligne_a_ajouter].controleur = lutin;
            else if (j == 3) lignes[ligne_a_ajouter].empaqueteur = lutin;
        }
    }

    printf("\nPlanning optimisé généré avec succès !\n");
}
