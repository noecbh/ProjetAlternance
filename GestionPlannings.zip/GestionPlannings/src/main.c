#include "../include/lutins.h"
#include "../include/plannings.h"
#include "../include/fichiers.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int i, choix, choix2;
    int nb_lutins = 9;
    int nb_lignes = 3;
    int jour = 1;  /* Lundi */
    int debut = 0, fin = 23;  /* Créneau horaire à tester */
    srand(time(NULL));

    /* Allocation et génération des lutins */
    Lutin *lutins = generer_lutin(nb_lutins);
    LigneFabrication lignes[nb_lignes];

    if (lutins == NULL) {
        printf("Erreur d'allocation mémoire des lutins.\n");
        return 1;
    }

    /* Affichage des lutins générés */
    printf("\nListe des lutins générés :\n");
    for (i = 0; i < nb_lutins; i++) {
        afficher_lutin(lutins[i]);
        printf("\n");
    }

    /* Choix du mode de génération */
    printf("\nSouhaitez-vous :\n");
    printf(" 1: Générer automatiquement\n");
    printf(" 2: Remplir manuellement\n");
    printf(" 3: Charger un planning\n");
    printf(" 4: Générer un planning optimisé\n");
    printf(" 5: Quitter\n");
    printf("Votre choix : ");
    
    if (scanf("%d", &choix) != 1) {
        printf("Erreur de saisie !\n");
        free(lutins);
        exit(EXIT_FAILURE);
    }

    /* Génération du planning en fonction du choix */
    if (choix == 1) {
        generer_planning(lutins, nb_lutins, lignes, nb_lignes, jour);
    } else if (choix == 2) {
        gerer_planning_manuel(lutins, nb_lutins, lignes, nb_lignes, jour, debut, fin);
    } else if (choix == 3) {
        charger_planning(lutins, &nb_lutins, lignes, &nb_lignes);
    } else if (choix == 4) {
        creer_planning_optimise(lutins, nb_lutins, lignes, nb_lignes, jour);
    } else if (choix == 5) {
        exit(EXIT_SUCCESS);
    } else {
        printf("Choix invalide !\n");
        free(lutins);
        exit(EXIT_FAILURE);
    }

    /* Affichage du planning généré */
    afficher_planning(lignes, nb_lignes, jour);

    /* Demande de sauvegarde */
    printf("\nSouhaitez-vous :\n");
    printf(" 1 : Sauvegarder le planning\n");
    printf(" 2 : Quitter\n");
    printf("Votre choix : ");

    if (scanf("%d", &choix2) != 1) {
        printf("Erreur de saisie !\n");
        free(lutins);
        return 1;
    }

    if (choix2 == 1) {
        sauvegarder_planning(lignes, nb_lignes, jour);
    }

    /* Libération de la mémoire */
    free(lutins);
    
    exit(EXIT_SUCCESS);
}
