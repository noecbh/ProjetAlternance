#ifndef PLANNINGS_H
#define PLANNINGS_H

#include "lutins.h"

typedef struct {
    Lutin *bricoleur;
    Lutin *controleur;
    Lutin *empaqueteur;
    PlageHoraire horaires[3];
} LigneFabrication;

void generer_planning(Lutin *lutins, int nb_lutins, LigneFabrication *lignes, int nb_lignes, int jour);
void afficher_planning(LigneFabrication *lignes, int nb_lignes, int jour);
void calculer_horaires_ligne(LigneFabrication *ligne);
void gerer_planning_manuel(Lutin *lutins, int nb_lutins, LigneFabrication *lignes, int nb_lignes, int jour, int debut, int fin);
void creer_planning_optimise(Lutin *lutins, int nb_lutins, LigneFabrication *lignes, int nb_lignes, int jour);



#endif